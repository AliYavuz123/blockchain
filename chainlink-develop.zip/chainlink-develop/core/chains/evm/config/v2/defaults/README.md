# Default Configurations

:warning: IMPORTANT :warning:

All config sets **inherit** from `fallback.toml` first and overwrite
fields as necessary. Do not create a new full configuration from
scratch.
